#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseStamped
import numpy as np

import tf2_ros
from geometry_msgs.msg import TransformStamped
from scipy.integrate import solve_ivp

class MobileRobotSimNode(Node):

    def __init__(self):
        super().__init__("mobile_robot_sim")
        self.declare_parameter("frequency", 2.0)
        self.signal_frequency = self.get_parameter("frequency").value

        self.pose_subscribe = self.create_subscription(Twist, "/control_topic", self.get_vel_callback, 10)
        self.linear_x = 0.0
        self.linear_y = 0.0
        self.angular_z = 0.0

        self.q_x = 0.0
        self.q_y = 0.0
        self.q_theta = 0.0

        self.pose_stamped_pub = self.create_publisher(PoseStamped, "/robot_pose", 10)
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)
        self.timer_pose_stamp = self.create_timer(1/self.signal_frequency, self.send_rob_pose)
        self.timer_tf = self.create_timer(1/self.signal_frequency, self.send_tf_pose)

    def ode_system(self, t, state, v_x, v_y, omega):
        x, y, theta = state
        dxdt = np.sqrt(v_x**2 + v_y**2) * np.cos(self.q_theta)
        dydt = np.sqrt(v_x**2 + v_y**2) * np.sin(self.q_theta)
        dthetadt = omega
        return [dxdt, dydt, dthetadt]

    def send_rob_pose(self):
        msg = PoseStamped() # publishing pose
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "map" 
        msg.pose.position.x = self.q_x
        msg.pose.position.y = self.q_y
        msg.pose.position.z = 0.0

        msg.pose.orientation.w = np.cos(self.q_theta/2)
        msg.pose.orientation.x = 0.0
        msg.pose.orientation.y = 0.0
        msg.pose.orientation.z = np.sin(self.q_theta/2)

        self.pose_stamped_pub.publish(msg)

    def send_tf_pose(self):
        transform = TransformStamped()
        transform.header.stamp = self.get_clock().now().to_msg()
        transform.header.frame_id = "map"
        transform.child_frame_id = "base_link" 

        transform.transform.translation.x = self.q_x
        transform.transform.translation.y = self.q_y
        transform.transform.translation.z = 0.0

        transform.transform.rotation.x = 0.0
        transform.transform.rotation.y = 0.0
        transform.transform.rotation.z = np.sin(self.q_theta / 2)
        transform.transform.rotation.w = np.cos(self.q_theta / 2)

        self.tf_broadcaster.sendTransform(transform)

    def get_vel_callback(self, msg: Twist):
        self.linear_x = msg.linear.x
        self.linear_y = msg.linear.y
        self.angular_z = msg.angular.z
        self.calculate_position()

    def calculate_position(self):
        initial_state = [self.q_x, self.q_y, self.q_theta]
        t_span = [0, 1/self.signal_frequency]
        solution = solve_ivp(self.ode_system, t_span, initial_state, args=(self.linear_x, self.linear_y, self.angular_z), t_eval=[t_span[1]])

        self.q_x, self.q_y, self.q_theta = solution.y[:, -1]
        self.q = [self.q_x, self.q_y, self.q_theta]
        self.get_logger().info(str(self.q))

def main(args=None):
    rclpy.init(args=args)
    node = MobileRobotSimNode()
    rclpy.spin(node)
    rclpy.shutdown()
