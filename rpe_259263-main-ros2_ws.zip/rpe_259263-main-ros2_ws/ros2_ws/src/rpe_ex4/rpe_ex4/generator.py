#!/usr/bin/env python3
import rclpy
import math

from rclpy.node import Node
from rpe_ex4_mess.msg import Sine


STEPS = 1000


class SinusGenerator(Node):
    def __init__(self):
        super().__init__("generator")
        self.cmd_sin_pub = self.create_publisher(Sine, "/signal", 10)
        self.declare_parameter("amplitude", 1.0)
        self.declare_parameter("frequency", 2.0)
        
        self.signal_amplitude = self.get_parameter("amplitude").value
        self.signal_frequency = self.get_parameter("frequency").value

        self.counter = 0.0
        self.timer_ = self.create_timer(1/STEPS, self.send_sinus)
        

    def send_sinus(self):
        msg = Sine()
        msg.data = self.signal_amplitude * math.sin( 2.0 * math.pi * self.signal_frequency * self.counter/STEPS) #self.signal_frequency * self.get_clock().now().seconds_nanoseconds()[0])
        self.cmd_sin_pub.publish(msg)
        self.counter += 1.0


def main(args=None):
    rclpy.init(args=args)
    node = SinusGenerator()
    rclpy.spin(node)
    rclpy.shutdown()

