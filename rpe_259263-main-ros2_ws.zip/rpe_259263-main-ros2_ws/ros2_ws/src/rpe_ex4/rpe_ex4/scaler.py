#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rpe_ex4_mess.msg import Sine


class ScalerNode(Node):

    def __init__(self):
        super().__init__("scaler")

        self.declare_parameter("factor", 2.0)
        self.signal_factor = self.get_parameter("factor").value
        self.sub_data = self.create_subscription(Sine, "/signal", self.mod_sin_callback, 10)
        self.cmd_mod_sin_pub = self.create_publisher(Sine, "/modified_signal", 10)

    def mod_sin_callback(self,msg: Sine):
        msg.data = msg.data * self.signal_factor
        self.cmd_mod_sin_pub.publish(msg)
        self.get_logger().info(str(msg))


def main(args=None):
    rclpy.init(args=args)
    node = ScalerNode()
    rclpy.spin(node)
    rclpy.shutdown()