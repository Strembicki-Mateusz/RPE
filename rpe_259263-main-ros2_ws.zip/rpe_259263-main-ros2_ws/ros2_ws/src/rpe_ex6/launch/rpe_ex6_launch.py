import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    """
    Generates a launch description for the my_signal_package ROS2 package.
    """
    ld = LaunchDescription()

    config = os.path.join(
        get_package_share_directory("rpe_ex6"),
        'config',
        'params.yaml',
    )

    rviz_config = os.path.join(
        get_package_share_directory("rpe_ex6"),
        'rviz',
        'rpe_ex6.rviz',
    )

    if not os.path.exists(rviz_config):
        raise FileNotFoundError(f"Plik konfiguracyjny RViz2 nie został znaleziony: {rviz_config}")


    control_node = Node(
        package="rpe_ex6",
        name="control",
        executable="control_node",
        parameters=[config],
    )

    mrs_node = Node(
        package="rpe_ex6",
        name="mobile_robot_simulator",
        executable="mrs_node",
        parameters=[config],
    )

    rviz2_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen",
        arguments=["-d", rviz_config]
    )

    ld.add_action(control_node)
    ld.add_action(mrs_node)
    ld.add_action(rviz2_node)
    return ld