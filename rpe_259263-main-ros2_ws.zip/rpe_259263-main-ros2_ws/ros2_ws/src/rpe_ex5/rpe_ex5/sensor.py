#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rpe_ex5_interfaces.msg import Sensor
import random
from rpe_ex5_interfaces.srv import Restart



class SensorPublisherNode(Node):

    def __init__(self):
        super().__init__("sensor")
        #self.tmp_name = "sensor"
        self.declare_parameter("frequency", 1.0)
        self.freq = self.get_parameter("frequency").value
        self.declare_parameter("sens_name", "hello")
        self.sens_name = self.get_parameter("sens_name").value

        self.counter = 0
        self.flag = 0

        self.pub_state = self.create_publisher(Sensor, "/sensor_state", 10)
        self.timer_ = self.create_timer(1/self.freq, self.send_sens_state)

        self.srv = self.create_service(Restart, 'restart_request', self.component_error_callback)
        
    def component_error_callback(self, request, response):
        if (request.restart == True) and (request.name == self.sens_name):
            response.done = True
            self.flag = 0
            self.counter = 0
            self.get_logger().warn('Restarting')
        else:
            response.done = False
        return response

    def send_sens_state(self):
        msg = Sensor()
        msg.name = self.sens_name
        self.x = 0.1
        if self.counter > 5:
            self.x = random.uniform(0,1)
            if self.x > 0.3:
                self.flag = 1

        if self.flag == 1:
            msg.data.data = False
        else:
            msg.data.data = True

        self.counter += 1
        self.pub_state.publish(msg)




def main(args=None):
    rclpy.init(args=args)
    node = SensorPublisherNode()
    rclpy.spin(node)
    rclpy.shutdown()

