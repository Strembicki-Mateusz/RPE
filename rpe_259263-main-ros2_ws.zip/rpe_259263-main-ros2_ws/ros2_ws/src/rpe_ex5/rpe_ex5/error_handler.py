import rclpy
from rclpy.node import Node
from rpe_ex5_interfaces.srv import ComponentError
from rpe_ex5_interfaces.srv import Restart


class ErrorHandler(Node):

    def __init__(self):
        super().__init__('error_handler')
        self.srv = self.create_service(ComponentError, 'component_error', self.component_error_callback)

        #array = ["one","two"]
        #self.declare_parameter("restart_request", array)
        #self.restart_request = self.get_parameter("restart_request").value
        #self.get_logger().info(str(self.topics))
        
        #for i in self.restart_request:
        self.cli = self.create_client(Restart, 'restart_request')
        while not self.cli.wait_for_service(timeout_sec=0.1):
            self.get_logger().warn('Service not available, waiting again...')
        self.req = Restart.Request()




    def send_request(self, error, name):
        self.req.restart = error
        self.req.name = name
        return self.cli.call_async(self.req)
      


    def component_error_callback(self, request, response):
        if request.value == False:
            response.error_occured = True
            self.get_logger().warn('Need restart - ' + str(request.name))
            self.send_request(response.error_occured, request.name)
        else:
            response.error_occured = False
            self.get_logger().info('Not needed restart ' + str(request.name))
        return response

def main(args=None):
    rclpy.init(args=args)
    node = ErrorHandler()
    rclpy.spin(node)
    rclpy.shutdown()




