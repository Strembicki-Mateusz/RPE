#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rpe_ex5_interfaces.msg import Sensor
from rpe_ex5_interfaces.srv import ComponentError
from std_msgs.msg import Bool



class SensorSubscriberNode(Node):
    def __init__(self):
        super().__init__("state_monitor")

        array = ["one","two"]
        self.declare_parameter("topics", array)
        self.topics = self.get_parameter("topics").value
        #self.get_logger().info(str(self.topics))
        
        for i in self.topics:
            #self.get_logger().info(str(i))
            self.sub_state = self.create_subscription(Sensor, str(i), self.sens_state_callback, 10)

        self.err_occ = True
        self.pub_state2 = self.create_publisher(Bool, "/rob_state", 10)
        self.timer_2 = self.create_timer(0.1, self.any_error)

        self.cli = self.create_client(ComponentError, 'component_error')
        while not self.cli.wait_for_service(timeout_sec=0.1):
            self.get_logger().warn('Service not available, waiting again...')
        self.req = ComponentError.Request()

    def any_error(self):
        msg = Bool()
        msg.data = self.err_occ
        self.get_logger().info("ROB STATE: " + str(msg.data))
        self.pub_state2.publish(msg)

    def send_request(self, error,name):
        self.req.value = error
        self.req.name = name
        #self.err_occ = False
        return self.cli.call_async(self.req)

    def sens_state_callback(self,msg: Sensor):
        error = msg.data.data
        name = msg.name
        if error == True:
            self.err_occ = True
        else:
            self.err_occ = False
        #elf.pub_state2.publish(error)
        self.get_logger().info(str(msg.name) + ": " + str(msg.data.data))
        self.send_request(error,name)



def main(args=None):
    rclpy.init(args=args)
    node = SensorSubscriberNode()
    rclpy.spin(node)
    rclpy.shutdown()