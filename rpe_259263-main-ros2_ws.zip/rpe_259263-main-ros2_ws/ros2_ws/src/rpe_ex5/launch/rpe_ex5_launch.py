import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
import yaml



def generate_launch_description():
    """
    Generates a launch description for the my_signal_package ROS2 package.
    """
    ld = LaunchDescription()

    topic_list = []
    request_list = []

    with open(os.path.join(get_package_share_directory("rpe_ex5"),'config', 'sensors.yaml')) as file:
        dict = yaml.safe_load(file)
       # print(dict)

    for x, obj in dict.items():
        name_list = obj['name']
        freq_list = obj['frequency']
        new = zip(name_list,freq_list)
        for i in name_list:
            topic_list.append(i + "_state")
            request_list.append(i + "_request")

    for i in new:
        sensor_node = Node(
            package="rpe_ex5",
            executable="sensor_node",
            name=str(i[0]),
            remappings= [
                ("sensor_state", str(i[0])+"_state")
                #("restart_request", str(i[0]+"_request"))
            ],
            parameters= [
                {"frequency": float(i[1])},
                {"sens_name": str(i[0])}
            ],
        )
        ld.add_action(sensor_node)

    state_monitor_node = Node(
        package="rpe_ex5",
        executable="state_monitor_node",
        name="state_monitor",
        parameters= [
            {"topics": topic_list}
        ],
    )
    ld.add_action(state_monitor_node)

    error_handler_node = Node(
        package="rpe_ex5",
        name="error_handler",
        executable="error_handler_node",
        parameters= [
            {"restart_request": request_list}
        ],
    )
    ld.add_action(error_handler_node)
    

    return ld