// generated from rosidl_generator_c/resource/idl.h.em
// with input from rpe_ex4_mess:msg/Sine.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX4_MESS__MSG__SINE_H_
#define RPE_EX4_MESS__MSG__SINE_H_

#include "rpe_ex4_mess/msg/detail/sine__struct.h"
#include "rpe_ex4_mess/msg/detail/sine__functions.h"
#include "rpe_ex4_mess/msg/detail/sine__type_support.h"

#endif  // RPE_EX4_MESS__MSG__SINE_H_
