// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from rpe_ex4_mess:msg/Sine.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX4_MESS__MSG__DETAIL__SINE__FUNCTIONS_H_
#define RPE_EX4_MESS__MSG__DETAIL__SINE__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "rpe_ex4_mess/msg/rosidl_generator_c__visibility_control.h"

#include "rpe_ex4_mess/msg/detail/sine__struct.h"

/// Initialize msg/Sine message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * rpe_ex4_mess__msg__Sine
 * )) before or use
 * rpe_ex4_mess__msg__Sine__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
bool
rpe_ex4_mess__msg__Sine__init(rpe_ex4_mess__msg__Sine * msg);

/// Finalize msg/Sine message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
void
rpe_ex4_mess__msg__Sine__fini(rpe_ex4_mess__msg__Sine * msg);

/// Create msg/Sine message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * rpe_ex4_mess__msg__Sine__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
rpe_ex4_mess__msg__Sine *
rpe_ex4_mess__msg__Sine__create();

/// Destroy msg/Sine message.
/**
 * It calls
 * rpe_ex4_mess__msg__Sine__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
void
rpe_ex4_mess__msg__Sine__destroy(rpe_ex4_mess__msg__Sine * msg);

/// Check for msg/Sine message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
bool
rpe_ex4_mess__msg__Sine__are_equal(const rpe_ex4_mess__msg__Sine * lhs, const rpe_ex4_mess__msg__Sine * rhs);

/// Copy a msg/Sine message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
bool
rpe_ex4_mess__msg__Sine__copy(
  const rpe_ex4_mess__msg__Sine * input,
  rpe_ex4_mess__msg__Sine * output);

/// Initialize array of msg/Sine messages.
/**
 * It allocates the memory for the number of elements and calls
 * rpe_ex4_mess__msg__Sine__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
bool
rpe_ex4_mess__msg__Sine__Sequence__init(rpe_ex4_mess__msg__Sine__Sequence * array, size_t size);

/// Finalize array of msg/Sine messages.
/**
 * It calls
 * rpe_ex4_mess__msg__Sine__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
void
rpe_ex4_mess__msg__Sine__Sequence__fini(rpe_ex4_mess__msg__Sine__Sequence * array);

/// Create array of msg/Sine messages.
/**
 * It allocates the memory for the array and calls
 * rpe_ex4_mess__msg__Sine__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
rpe_ex4_mess__msg__Sine__Sequence *
rpe_ex4_mess__msg__Sine__Sequence__create(size_t size);

/// Destroy array of msg/Sine messages.
/**
 * It calls
 * rpe_ex4_mess__msg__Sine__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
void
rpe_ex4_mess__msg__Sine__Sequence__destroy(rpe_ex4_mess__msg__Sine__Sequence * array);

/// Check for msg/Sine message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
bool
rpe_ex4_mess__msg__Sine__Sequence__are_equal(const rpe_ex4_mess__msg__Sine__Sequence * lhs, const rpe_ex4_mess__msg__Sine__Sequence * rhs);

/// Copy an array of msg/Sine messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_rpe_ex4_mess
bool
rpe_ex4_mess__msg__Sine__Sequence__copy(
  const rpe_ex4_mess__msg__Sine__Sequence * input,
  rpe_ex4_mess__msg__Sine__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // RPE_EX4_MESS__MSG__DETAIL__SINE__FUNCTIONS_H_
