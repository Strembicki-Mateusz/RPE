// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from rpe_ex4_mess:msg/Sine.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX4_MESS__MSG__DETAIL__SINE__BUILDER_HPP_
#define RPE_EX4_MESS__MSG__DETAIL__SINE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "rpe_ex4_mess/msg/detail/sine__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace rpe_ex4_mess
{

namespace msg
{

namespace builder
{

class Init_Sine_data
{
public:
  Init_Sine_data()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::rpe_ex4_mess::msg::Sine data(::rpe_ex4_mess::msg::Sine::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rpe_ex4_mess::msg::Sine msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::rpe_ex4_mess::msg::Sine>()
{
  return rpe_ex4_mess::msg::builder::Init_Sine_data();
}

}  // namespace rpe_ex4_mess

#endif  // RPE_EX4_MESS__MSG__DETAIL__SINE__BUILDER_HPP_
