// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RPE_EX4_MESS__MSG__SINE_HPP_
#define RPE_EX4_MESS__MSG__SINE_HPP_

#include "rpe_ex4_mess/msg/detail/sine__struct.hpp"
#include "rpe_ex4_mess/msg/detail/sine__builder.hpp"
#include "rpe_ex4_mess/msg/detail/sine__traits.hpp"

#endif  // RPE_EX4_MESS__MSG__SINE_HPP_
