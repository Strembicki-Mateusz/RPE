// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from rpe_ex4_mess:msg/Sine.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX4_MESS__MSG__DETAIL__SINE__STRUCT_H_
#define RPE_EX4_MESS__MSG__DETAIL__SINE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/Sine in the package rpe_ex4_mess.
typedef struct rpe_ex4_mess__msg__Sine
{
  double data;
} rpe_ex4_mess__msg__Sine;

// Struct for a sequence of rpe_ex4_mess__msg__Sine.
typedef struct rpe_ex4_mess__msg__Sine__Sequence
{
  rpe_ex4_mess__msg__Sine * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} rpe_ex4_mess__msg__Sine__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RPE_EX4_MESS__MSG__DETAIL__SINE__STRUCT_H_
