// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from rpe_ex5_srv:srv/Error.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_SRV__SRV__DETAIL__ERROR__BUILDER_HPP_
#define RPE_EX5_SRV__SRV__DETAIL__ERROR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "rpe_ex5_srv/srv/detail/error__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace rpe_ex5_srv
{

namespace srv
{

namespace builder
{

class Init_Error_Request_sensor_name
{
public:
  Init_Error_Request_sensor_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::rpe_ex5_srv::srv::Error_Request sensor_name(::rpe_ex5_srv::srv::Error_Request::_sensor_name_type arg)
  {
    msg_.sensor_name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rpe_ex5_srv::srv::Error_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::rpe_ex5_srv::srv::Error_Request>()
{
  return rpe_ex5_srv::srv::builder::Init_Error_Request_sensor_name();
}

}  // namespace rpe_ex5_srv


namespace rpe_ex5_srv
{

namespace srv
{

namespace builder
{

class Init_Error_Response_error_occured
{
public:
  Init_Error_Response_error_occured()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::rpe_ex5_srv::srv::Error_Response error_occured(::rpe_ex5_srv::srv::Error_Response::_error_occured_type arg)
  {
    msg_.error_occured = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rpe_ex5_srv::srv::Error_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::rpe_ex5_srv::srv::Error_Response>()
{
  return rpe_ex5_srv::srv::builder::Init_Error_Response_error_occured();
}

}  // namespace rpe_ex5_srv

#endif  // RPE_EX5_SRV__SRV__DETAIL__ERROR__BUILDER_HPP_
