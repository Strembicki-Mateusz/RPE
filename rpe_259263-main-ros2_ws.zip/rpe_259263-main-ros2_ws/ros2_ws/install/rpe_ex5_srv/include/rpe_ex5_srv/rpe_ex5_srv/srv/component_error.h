// generated from rosidl_generator_c/resource/idl.h.em
// with input from rpe_ex5_srv:srv/ComponentError.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_SRV__SRV__COMPONENT_ERROR_H_
#define RPE_EX5_SRV__SRV__COMPONENT_ERROR_H_

#include "rpe_ex5_srv/srv/detail/component_error__struct.h"
#include "rpe_ex5_srv/srv/detail/component_error__functions.h"
#include "rpe_ex5_srv/srv/detail/component_error__type_support.h"

#endif  // RPE_EX5_SRV__SRV__COMPONENT_ERROR_H_
