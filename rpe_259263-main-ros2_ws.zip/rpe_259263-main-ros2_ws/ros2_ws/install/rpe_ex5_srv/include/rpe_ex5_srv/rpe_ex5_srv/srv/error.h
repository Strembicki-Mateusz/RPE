// generated from rosidl_generator_c/resource/idl.h.em
// with input from rpe_ex5_srv:srv/Error.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_SRV__SRV__ERROR_H_
#define RPE_EX5_SRV__SRV__ERROR_H_

#include "rpe_ex5_srv/srv/detail/error__struct.h"
#include "rpe_ex5_srv/srv/detail/error__functions.h"
#include "rpe_ex5_srv/srv/detail/error__type_support.h"

#endif  // RPE_EX5_SRV__SRV__ERROR_H_
