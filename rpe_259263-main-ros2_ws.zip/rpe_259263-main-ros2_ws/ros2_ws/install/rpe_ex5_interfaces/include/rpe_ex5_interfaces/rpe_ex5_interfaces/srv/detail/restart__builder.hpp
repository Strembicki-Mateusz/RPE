// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from rpe_ex5_interfaces:srv/Restart.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__SRV__DETAIL__RESTART__BUILDER_HPP_
#define RPE_EX5_INTERFACES__SRV__DETAIL__RESTART__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "rpe_ex5_interfaces/srv/detail/restart__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace rpe_ex5_interfaces
{

namespace srv
{

namespace builder
{

class Init_Restart_Request_name
{
public:
  explicit Init_Restart_Request_name(::rpe_ex5_interfaces::srv::Restart_Request & msg)
  : msg_(msg)
  {}
  ::rpe_ex5_interfaces::srv::Restart_Request name(::rpe_ex5_interfaces::srv::Restart_Request::_name_type arg)
  {
    msg_.name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rpe_ex5_interfaces::srv::Restart_Request msg_;
};

class Init_Restart_Request_restart
{
public:
  Init_Restart_Request_restart()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Restart_Request_name restart(::rpe_ex5_interfaces::srv::Restart_Request::_restart_type arg)
  {
    msg_.restart = std::move(arg);
    return Init_Restart_Request_name(msg_);
  }

private:
  ::rpe_ex5_interfaces::srv::Restart_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::rpe_ex5_interfaces::srv::Restart_Request>()
{
  return rpe_ex5_interfaces::srv::builder::Init_Restart_Request_restart();
}

}  // namespace rpe_ex5_interfaces


namespace rpe_ex5_interfaces
{

namespace srv
{

namespace builder
{

class Init_Restart_Response_done
{
public:
  Init_Restart_Response_done()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::rpe_ex5_interfaces::srv::Restart_Response done(::rpe_ex5_interfaces::srv::Restart_Response::_done_type arg)
  {
    msg_.done = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rpe_ex5_interfaces::srv::Restart_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::rpe_ex5_interfaces::srv::Restart_Response>()
{
  return rpe_ex5_interfaces::srv::builder::Init_Restart_Response_done();
}

}  // namespace rpe_ex5_interfaces

#endif  // RPE_EX5_INTERFACES__SRV__DETAIL__RESTART__BUILDER_HPP_
