// generated from rosidl_generator_c/resource/idl.h.em
// with input from rpe_ex5_interfaces:msg/SensorMsg.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__MSG__SENSOR_MSG_H_
#define RPE_EX5_INTERFACES__MSG__SENSOR_MSG_H_

#include "rpe_ex5_interfaces/msg/detail/sensor_msg__struct.h"
#include "rpe_ex5_interfaces/msg/detail/sensor_msg__functions.h"
#include "rpe_ex5_interfaces/msg/detail/sensor_msg__type_support.h"

#endif  // RPE_EX5_INTERFACES__MSG__SENSOR_MSG_H_
