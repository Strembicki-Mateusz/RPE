// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__SRV__COMPONENT_ERROR_HPP_
#define RPE_EX5_INTERFACES__SRV__COMPONENT_ERROR_HPP_

#include "rpe_ex5_interfaces/srv/detail/component_error__struct.hpp"
#include "rpe_ex5_interfaces/srv/detail/component_error__builder.hpp"
#include "rpe_ex5_interfaces/srv/detail/component_error__traits.hpp"

#endif  // RPE_EX5_INTERFACES__SRV__COMPONENT_ERROR_HPP_
