// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from rpe_ex5_interfaces:srv/Restart.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__SRV__DETAIL__RESTART__TRAITS_HPP_
#define RPE_EX5_INTERFACES__SRV__DETAIL__RESTART__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "rpe_ex5_interfaces/srv/detail/restart__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace rpe_ex5_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const Restart_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: restart
  {
    out << "restart: ";
    rosidl_generator_traits::value_to_yaml(msg.restart, out);
    out << ", ";
  }

  // member: name
  {
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Restart_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: restart
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "restart: ";
    rosidl_generator_traits::value_to_yaml(msg.restart, out);
    out << "\n";
  }

  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Restart_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace rpe_ex5_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use rpe_ex5_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const rpe_ex5_interfaces::srv::Restart_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  rpe_ex5_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use rpe_ex5_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const rpe_ex5_interfaces::srv::Restart_Request & msg)
{
  return rpe_ex5_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<rpe_ex5_interfaces::srv::Restart_Request>()
{
  return "rpe_ex5_interfaces::srv::Restart_Request";
}

template<>
inline const char * name<rpe_ex5_interfaces::srv::Restart_Request>()
{
  return "rpe_ex5_interfaces/srv/Restart_Request";
}

template<>
struct has_fixed_size<rpe_ex5_interfaces::srv::Restart_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<rpe_ex5_interfaces::srv::Restart_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<rpe_ex5_interfaces::srv::Restart_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rpe_ex5_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const Restart_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: done
  {
    out << "done: ";
    rosidl_generator_traits::value_to_yaml(msg.done, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Restart_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: done
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "done: ";
    rosidl_generator_traits::value_to_yaml(msg.done, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Restart_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace rpe_ex5_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use rpe_ex5_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const rpe_ex5_interfaces::srv::Restart_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  rpe_ex5_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use rpe_ex5_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const rpe_ex5_interfaces::srv::Restart_Response & msg)
{
  return rpe_ex5_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<rpe_ex5_interfaces::srv::Restart_Response>()
{
  return "rpe_ex5_interfaces::srv::Restart_Response";
}

template<>
inline const char * name<rpe_ex5_interfaces::srv::Restart_Response>()
{
  return "rpe_ex5_interfaces/srv/Restart_Response";
}

template<>
struct has_fixed_size<rpe_ex5_interfaces::srv::Restart_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<rpe_ex5_interfaces::srv::Restart_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<rpe_ex5_interfaces::srv::Restart_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<rpe_ex5_interfaces::srv::Restart>()
{
  return "rpe_ex5_interfaces::srv::Restart";
}

template<>
inline const char * name<rpe_ex5_interfaces::srv::Restart>()
{
  return "rpe_ex5_interfaces/srv/Restart";
}

template<>
struct has_fixed_size<rpe_ex5_interfaces::srv::Restart>
  : std::integral_constant<
    bool,
    has_fixed_size<rpe_ex5_interfaces::srv::Restart_Request>::value &&
    has_fixed_size<rpe_ex5_interfaces::srv::Restart_Response>::value
  >
{
};

template<>
struct has_bounded_size<rpe_ex5_interfaces::srv::Restart>
  : std::integral_constant<
    bool,
    has_bounded_size<rpe_ex5_interfaces::srv::Restart_Request>::value &&
    has_bounded_size<rpe_ex5_interfaces::srv::Restart_Response>::value
  >
{
};

template<>
struct is_service<rpe_ex5_interfaces::srv::Restart>
  : std::true_type
{
};

template<>
struct is_service_request<rpe_ex5_interfaces::srv::Restart_Request>
  : std::true_type
{
};

template<>
struct is_service_response<rpe_ex5_interfaces::srv::Restart_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // RPE_EX5_INTERFACES__SRV__DETAIL__RESTART__TRAITS_HPP_
