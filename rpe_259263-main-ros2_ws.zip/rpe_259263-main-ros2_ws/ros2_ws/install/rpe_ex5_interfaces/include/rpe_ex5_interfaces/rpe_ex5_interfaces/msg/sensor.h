// generated from rosidl_generator_c/resource/idl.h.em
// with input from rpe_ex5_interfaces:msg/Sensor.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__MSG__SENSOR_H_
#define RPE_EX5_INTERFACES__MSG__SENSOR_H_

#include "rpe_ex5_interfaces/msg/detail/sensor__struct.h"
#include "rpe_ex5_interfaces/msg/detail/sensor__functions.h"
#include "rpe_ex5_interfaces/msg/detail/sensor__type_support.h"

#endif  // RPE_EX5_INTERFACES__MSG__SENSOR_H_
