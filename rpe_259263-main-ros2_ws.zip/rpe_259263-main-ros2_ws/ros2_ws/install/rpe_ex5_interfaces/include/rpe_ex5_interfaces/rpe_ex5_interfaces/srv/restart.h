// generated from rosidl_generator_c/resource/idl.h.em
// with input from rpe_ex5_interfaces:srv/Restart.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__SRV__RESTART_H_
#define RPE_EX5_INTERFACES__SRV__RESTART_H_

#include "rpe_ex5_interfaces/srv/detail/restart__struct.h"
#include "rpe_ex5_interfaces/srv/detail/restart__functions.h"
#include "rpe_ex5_interfaces/srv/detail/restart__type_support.h"

#endif  // RPE_EX5_INTERFACES__SRV__RESTART_H_
