// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__MSG__SENSOR_MSG_HPP_
#define RPE_EX5_INTERFACES__MSG__SENSOR_MSG_HPP_

#include "rpe_ex5_interfaces/msg/detail/sensor_msg__struct.hpp"
#include "rpe_ex5_interfaces/msg/detail/sensor_msg__builder.hpp"
#include "rpe_ex5_interfaces/msg/detail/sensor_msg__traits.hpp"

#endif  // RPE_EX5_INTERFACES__MSG__SENSOR_MSG_HPP_
