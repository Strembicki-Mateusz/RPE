// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from rpe_ex5_interfaces:msg/SensorMsg.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__MSG__DETAIL__SENSOR_MSG__BUILDER_HPP_
#define RPE_EX5_INTERFACES__MSG__DETAIL__SENSOR_MSG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "rpe_ex5_interfaces/msg/detail/sensor_msg__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace rpe_ex5_interfaces
{

namespace msg
{

namespace builder
{

class Init_SensorMsg_name
{
public:
  explicit Init_SensorMsg_name(::rpe_ex5_interfaces::msg::SensorMsg & msg)
  : msg_(msg)
  {}
  ::rpe_ex5_interfaces::msg::SensorMsg name(::rpe_ex5_interfaces::msg::SensorMsg::_name_type arg)
  {
    msg_.name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rpe_ex5_interfaces::msg::SensorMsg msg_;
};

class Init_SensorMsg_data
{
public:
  Init_SensorMsg_data()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SensorMsg_name data(::rpe_ex5_interfaces::msg::SensorMsg::_data_type arg)
  {
    msg_.data = std::move(arg);
    return Init_SensorMsg_name(msg_);
  }

private:
  ::rpe_ex5_interfaces::msg::SensorMsg msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::rpe_ex5_interfaces::msg::SensorMsg>()
{
  return rpe_ex5_interfaces::msg::builder::Init_SensorMsg_data();
}

}  // namespace rpe_ex5_interfaces

#endif  // RPE_EX5_INTERFACES__MSG__DETAIL__SENSOR_MSG__BUILDER_HPP_
