// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from rpe_ex5_interfaces:msg/SensorMsg.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__MSG__DETAIL__SENSOR_MSG__STRUCT_HPP_
#define RPE_EX5_INTERFACES__MSG__DETAIL__SENSOR_MSG__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'data'
#include "std_msgs/msg/detail/bool__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__rpe_ex5_interfaces__msg__SensorMsg __attribute__((deprecated))
#else
# define DEPRECATED__rpe_ex5_interfaces__msg__SensorMsg __declspec(deprecated)
#endif

namespace rpe_ex5_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SensorMsg_
{
  using Type = SensorMsg_<ContainerAllocator>;

  explicit SensorMsg_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : data(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
    }
  }

  explicit SensorMsg_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : data(_alloc, _init),
    name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
    }
  }

  // field types and members
  using _data_type =
    std_msgs::msg::Bool_<ContainerAllocator>;
  _data_type data;
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;

  // setters for named parameter idiom
  Type & set__data(
    const std_msgs::msg::Bool_<ContainerAllocator> & _arg)
  {
    this->data = _arg;
    return *this;
  }
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator> *;
  using ConstRawPtr =
    const rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__rpe_ex5_interfaces__msg__SensorMsg
    std::shared_ptr<rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__rpe_ex5_interfaces__msg__SensorMsg
    std::shared_ptr<rpe_ex5_interfaces::msg::SensorMsg_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SensorMsg_ & other) const
  {
    if (this->data != other.data) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    return true;
  }
  bool operator!=(const SensorMsg_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SensorMsg_

// alias to use template instance with default allocator
using SensorMsg =
  rpe_ex5_interfaces::msg::SensorMsg_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace rpe_ex5_interfaces

#endif  // RPE_EX5_INTERFACES__MSG__DETAIL__SENSOR_MSG__STRUCT_HPP_
