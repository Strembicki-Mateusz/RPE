// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__MSG__SENSOR_HPP_
#define RPE_EX5_INTERFACES__MSG__SENSOR_HPP_

#include "rpe_ex5_interfaces/msg/detail/sensor__struct.hpp"
#include "rpe_ex5_interfaces/msg/detail/sensor__builder.hpp"
#include "rpe_ex5_interfaces/msg/detail/sensor__traits.hpp"

#endif  // RPE_EX5_INTERFACES__MSG__SENSOR_HPP_
