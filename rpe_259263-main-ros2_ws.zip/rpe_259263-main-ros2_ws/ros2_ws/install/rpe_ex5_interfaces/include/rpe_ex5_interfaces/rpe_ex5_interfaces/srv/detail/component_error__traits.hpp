// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from rpe_ex5_interfaces:srv/ComponentError.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__SRV__DETAIL__COMPONENT_ERROR__TRAITS_HPP_
#define RPE_EX5_INTERFACES__SRV__DETAIL__COMPONENT_ERROR__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "rpe_ex5_interfaces/srv/detail/component_error__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace rpe_ex5_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const ComponentError_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: value
  {
    out << "value: ";
    rosidl_generator_traits::value_to_yaml(msg.value, out);
    out << ", ";
  }

  // member: name
  {
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ComponentError_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: value
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "value: ";
    rosidl_generator_traits::value_to_yaml(msg.value, out);
    out << "\n";
  }

  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ComponentError_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace rpe_ex5_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use rpe_ex5_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const rpe_ex5_interfaces::srv::ComponentError_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  rpe_ex5_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use rpe_ex5_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const rpe_ex5_interfaces::srv::ComponentError_Request & msg)
{
  return rpe_ex5_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<rpe_ex5_interfaces::srv::ComponentError_Request>()
{
  return "rpe_ex5_interfaces::srv::ComponentError_Request";
}

template<>
inline const char * name<rpe_ex5_interfaces::srv::ComponentError_Request>()
{
  return "rpe_ex5_interfaces/srv/ComponentError_Request";
}

template<>
struct has_fixed_size<rpe_ex5_interfaces::srv::ComponentError_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<rpe_ex5_interfaces::srv::ComponentError_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<rpe_ex5_interfaces::srv::ComponentError_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rpe_ex5_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const ComponentError_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: error_occured
  {
    out << "error_occured: ";
    rosidl_generator_traits::value_to_yaml(msg.error_occured, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ComponentError_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: error_occured
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "error_occured: ";
    rosidl_generator_traits::value_to_yaml(msg.error_occured, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ComponentError_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace rpe_ex5_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use rpe_ex5_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const rpe_ex5_interfaces::srv::ComponentError_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  rpe_ex5_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use rpe_ex5_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const rpe_ex5_interfaces::srv::ComponentError_Response & msg)
{
  return rpe_ex5_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<rpe_ex5_interfaces::srv::ComponentError_Response>()
{
  return "rpe_ex5_interfaces::srv::ComponentError_Response";
}

template<>
inline const char * name<rpe_ex5_interfaces::srv::ComponentError_Response>()
{
  return "rpe_ex5_interfaces/srv/ComponentError_Response";
}

template<>
struct has_fixed_size<rpe_ex5_interfaces::srv::ComponentError_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<rpe_ex5_interfaces::srv::ComponentError_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<rpe_ex5_interfaces::srv::ComponentError_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<rpe_ex5_interfaces::srv::ComponentError>()
{
  return "rpe_ex5_interfaces::srv::ComponentError";
}

template<>
inline const char * name<rpe_ex5_interfaces::srv::ComponentError>()
{
  return "rpe_ex5_interfaces/srv/ComponentError";
}

template<>
struct has_fixed_size<rpe_ex5_interfaces::srv::ComponentError>
  : std::integral_constant<
    bool,
    has_fixed_size<rpe_ex5_interfaces::srv::ComponentError_Request>::value &&
    has_fixed_size<rpe_ex5_interfaces::srv::ComponentError_Response>::value
  >
{
};

template<>
struct has_bounded_size<rpe_ex5_interfaces::srv::ComponentError>
  : std::integral_constant<
    bool,
    has_bounded_size<rpe_ex5_interfaces::srv::ComponentError_Request>::value &&
    has_bounded_size<rpe_ex5_interfaces::srv::ComponentError_Response>::value
  >
{
};

template<>
struct is_service<rpe_ex5_interfaces::srv::ComponentError>
  : std::true_type
{
};

template<>
struct is_service_request<rpe_ex5_interfaces::srv::ComponentError_Request>
  : std::true_type
{
};

template<>
struct is_service_response<rpe_ex5_interfaces::srv::ComponentError_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // RPE_EX5_INTERFACES__SRV__DETAIL__COMPONENT_ERROR__TRAITS_HPP_
