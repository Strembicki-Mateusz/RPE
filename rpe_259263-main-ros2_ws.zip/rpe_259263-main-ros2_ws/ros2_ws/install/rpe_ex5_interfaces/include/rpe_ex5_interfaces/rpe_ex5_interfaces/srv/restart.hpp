// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__SRV__RESTART_HPP_
#define RPE_EX5_INTERFACES__SRV__RESTART_HPP_

#include "rpe_ex5_interfaces/srv/detail/restart__struct.hpp"
#include "rpe_ex5_interfaces/srv/detail/restart__builder.hpp"
#include "rpe_ex5_interfaces/srv/detail/restart__traits.hpp"

#endif  // RPE_EX5_INTERFACES__SRV__RESTART_HPP_
