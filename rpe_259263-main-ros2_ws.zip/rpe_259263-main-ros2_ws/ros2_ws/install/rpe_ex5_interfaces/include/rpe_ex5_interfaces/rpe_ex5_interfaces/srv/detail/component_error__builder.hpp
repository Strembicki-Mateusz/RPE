// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from rpe_ex5_interfaces:srv/ComponentError.idl
// generated code does not contain a copyright notice

#ifndef RPE_EX5_INTERFACES__SRV__DETAIL__COMPONENT_ERROR__BUILDER_HPP_
#define RPE_EX5_INTERFACES__SRV__DETAIL__COMPONENT_ERROR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "rpe_ex5_interfaces/srv/detail/component_error__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace rpe_ex5_interfaces
{

namespace srv
{

namespace builder
{

class Init_ComponentError_Request_name
{
public:
  explicit Init_ComponentError_Request_name(::rpe_ex5_interfaces::srv::ComponentError_Request & msg)
  : msg_(msg)
  {}
  ::rpe_ex5_interfaces::srv::ComponentError_Request name(::rpe_ex5_interfaces::srv::ComponentError_Request::_name_type arg)
  {
    msg_.name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rpe_ex5_interfaces::srv::ComponentError_Request msg_;
};

class Init_ComponentError_Request_value
{
public:
  Init_ComponentError_Request_value()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ComponentError_Request_name value(::rpe_ex5_interfaces::srv::ComponentError_Request::_value_type arg)
  {
    msg_.value = std::move(arg);
    return Init_ComponentError_Request_name(msg_);
  }

private:
  ::rpe_ex5_interfaces::srv::ComponentError_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::rpe_ex5_interfaces::srv::ComponentError_Request>()
{
  return rpe_ex5_interfaces::srv::builder::Init_ComponentError_Request_value();
}

}  // namespace rpe_ex5_interfaces


namespace rpe_ex5_interfaces
{

namespace srv
{

namespace builder
{

class Init_ComponentError_Response_error_occured
{
public:
  Init_ComponentError_Response_error_occured()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::rpe_ex5_interfaces::srv::ComponentError_Response error_occured(::rpe_ex5_interfaces::srv::ComponentError_Response::_error_occured_type arg)
  {
    msg_.error_occured = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rpe_ex5_interfaces::srv::ComponentError_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::rpe_ex5_interfaces::srv::ComponentError_Response>()
{
  return rpe_ex5_interfaces::srv::builder::Init_ComponentError_Response_error_occured();
}

}  // namespace rpe_ex5_interfaces

#endif  // RPE_EX5_INTERFACES__SRV__DETAIL__COMPONENT_ERROR__BUILDER_HPP_
