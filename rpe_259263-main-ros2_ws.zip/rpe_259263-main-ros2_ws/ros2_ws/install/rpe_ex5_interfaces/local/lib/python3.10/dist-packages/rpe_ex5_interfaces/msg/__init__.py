from rpe_ex5_interfaces.msg._sensor import Sensor  # noqa: F401
