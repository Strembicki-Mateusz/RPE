import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    """
    Generates a launch description for the my_signal_package ROS2 package.
    """
    ld = LaunchDescription()

    config_generator = os.path.join(
        get_package_share_directory("rpe_ex4"),
        'config',
        'generator_params.yaml',
    )

    config_scaler = os.path.join(
        get_package_share_directory("rpe_ex4"),
        'config',
        'generator_params.yaml',
    )

    generator_node = Node(
        package="rpe_ex4",
        name="generator",
        executable="generator_node",
        parameters=[config_generator],
    )

    scaler_node = Node(
        package="rpe_ex4",
        name="scaler",
        executable="scaler_node",
        parameters=[config_scaler],
    )

    rqt_plot_node = Node(
        package="rqt_plot",
        executable="rqt_plot",
        name="rqt_plot",
        output="screen",
        arguments=["/signal/data", "/modified_signal/data"],
    )

    ld.add_action(generator_node)
    ld.add_action(scaler_node)
    ld.add_action(rqt_plot_node)
    return ld